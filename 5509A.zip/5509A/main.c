/*
 * Copyright (C) 2003 Texas Instruments Incorporated
 * All Rights Reserved
 */
/*
 *---------main_i2c2.c---------
 * This example shows how to use the I2C API to transfer a byte of
 * data in loopback mode.
 */

#include <csl_i2c.h>
#include <csl.h>
#include <csl_dma.h>
#include <stdio.h>

//---------Global data definition---------
int x,y,z;
Uint16 databyte1[1]={0xA};
Uint16 datareceive1[1]={0};
Uint16 A[10] = {15,54,19,26,125,136,49,264,81,100};
Uint16 B[10] = {100,90,80,70,60,50,40,30,20,10};
/* Create and initialize an I2C initialization structure */
I2C_Setup Init = {
        0,              /* 7 bit address mode */
        0x0020,         /* own address - don't care if master */
        144,            /* clkout value (Mhz)  */
        400,            /* a number between 10 and 400*/
        0,              /* number of bits/byte to be received or transmitted (8)*/
        1,              /* DLB mode on*/
        1               /* FREE mode of operation on*/
};


//---------Function prototypes---------
void taskFunc(void);
void DSPFunction(Uint16* input, Uint16 * filter, int windowSize, int dataSize, Uint16 *result) {
    int i,j,k;
    for (i=0 ; i< windowSize; i++){
        for (j=0; j + windowSize <= dataSize; j++){
            for (k=0; k < windowSize; k++)
            // elementwise multiply
                result[k] += input[j+k] * filter[j];
        }
    }
}
//---------main routine---------
void main(void)
{
    /* Initialize CSL library - This is REQUIRED !!! */
    CSL_init();
    //DMA_Config myconfig;
    /* Call I2C example task/func */
    while (1){
    taskFunc();
    Uint16 buffer[100];
    DSPFunction(A,B,2,10,buffer);
    }
}

void taskFunc(void) {

    int err = 1;
    /* Initialize I2C, using parameters in init structure */
    I2C_setup(&Init);

    /* Write a data byte to I2C */
    x=I2C_write(databyte1,1,1,0x20,1,30000);

    /* Read data byte from I2C */
    z=I2C_read(datareceive1,1,1,0x20,1,30000,0);

    /* Make sure the received byte is same as one sent */
    if (databyte1[0]==datareceive1[0]) {
       err = 0;
    }
    printf ("%s\n",err?"TEST FAILED" : "TEST PASSED");
}



